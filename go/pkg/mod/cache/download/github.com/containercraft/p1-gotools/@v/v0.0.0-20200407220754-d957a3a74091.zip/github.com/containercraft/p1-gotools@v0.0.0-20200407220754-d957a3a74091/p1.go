package main

import "github.com/tcynic/p1-gotools/text"

func main() {
	text.PrintIntro()
}
