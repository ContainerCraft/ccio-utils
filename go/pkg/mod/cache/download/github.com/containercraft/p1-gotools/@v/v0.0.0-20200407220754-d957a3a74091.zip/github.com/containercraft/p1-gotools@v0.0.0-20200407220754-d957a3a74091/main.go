package main

import "github.com/containercraft/p1-gotools/src/text"

func main() {
    text.printIntro()
}

