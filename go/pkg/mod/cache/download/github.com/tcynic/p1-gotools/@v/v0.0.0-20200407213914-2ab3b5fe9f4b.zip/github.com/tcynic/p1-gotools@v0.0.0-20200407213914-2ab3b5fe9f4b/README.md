# p1-gotools
golang dev tool for p1 init script utilities
